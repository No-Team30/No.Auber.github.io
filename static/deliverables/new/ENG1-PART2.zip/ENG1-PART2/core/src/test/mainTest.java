import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.assertEquals;

public class mainTest {
    @Test
    @DisplayName("Sample")
    void someTest() {
        assertEquals(1, 2);
    }
}
